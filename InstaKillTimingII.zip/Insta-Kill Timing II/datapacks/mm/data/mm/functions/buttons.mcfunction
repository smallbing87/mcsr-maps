execute if block 1 102 -100 #minecraft:buttons[powered=true] run scoreboard players add bDI goofy 1
execute if block 1 102 -102 #minecraft:buttons[powered=true] run scoreboard players add bSV goofy 1
execute if block 1 102 -104 #minecraft:buttons[powered=true] run scoreboard players add bPM goofy 1
execute if block -1 102 -100 #minecraft:buttons[powered=true] run scoreboard players add bPH goofy 1
execute if block -1 102 -102 #minecraft:buttons[powered=true] run scoreboard players add bFD goofy 1
execute if block -1 102 -104 #minecraft:buttons[powered=true] run scoreboard players add bAD goofy 1
execute if score bDI goofy matches 2.. run scoreboard players set bDI goofy 0
execute if score bSV goofy matches 2.. run scoreboard players set bSV goofy 0
execute if score bPM goofy matches 2.. run scoreboard players set bPM goofy 0
execute if score bPH goofy matches 2.. run scoreboard players set bPH goofy 0
execute if score bFD goofy matches 2.. run scoreboard players set bFD goofy 0
execute if score bAD goofy matches 2.. run scoreboard players set bAD goofy 0
execute if block 1 102 -100 #minecraft:buttons[powered=true] if score bDI goofy matches 0 run setblock 2 102 -100 red_terracotta
execute if block 1 102 -102 #minecraft:buttons[powered=true] if score bSV goofy matches 0 run setblock 2 102 -102 red_terracotta
execute if block 1 102 -104 #minecraft:buttons[powered=true] if score bPM goofy matches 0 run setblock 2 102 -104 light_blue_terracotta
execute if block -1 102 -100 #minecraft:buttons[powered=true] if score bPH goofy matches 0 run setblock -2 102 -100 red_terracotta
execute if block -1 102 -104 #minecraft:buttons[powered=true] if score bAD goofy matches 0 run setblock -2 102 -104 red_terracotta
execute if block -1 102 -102 #minecraft:buttons[powered=true] if score bFD goofy matches 0 run setblock -2 102 -102 red_terracotta
execute if block 1 102 -100 #minecraft:buttons[powered=true] if score bDI goofy matches 1 run setblock 2 102 -100 lime_terracotta
execute if block 1 102 -102 #minecraft:buttons[powered=true] if score bSV goofy matches 1 run setblock 2 102 -102 lime_terracotta
execute if block 1 102 -104 #minecraft:buttons[powered=true] if score bPM goofy matches 1 run setblock 2 102 -104 blue_terracotta
execute if block -1 102 -100 #minecraft:buttons[powered=true] if score bPH goofy matches 1 run setblock -2 102 -100 lime_terracotta
execute if block -1 102 -102 #minecraft:buttons[powered=true] if score bFD goofy matches 1 run setblock -2 102 -102 lime_terracotta
execute if block -1 102 -104 #minecraft:buttons[powered=true] if score bAD goofy matches 1 run setblock -2 102 -104 lime_terracotta

execute if block 1 102 -104 #minecraft:buttons[powered=true] if score bPM goofy matches 0 run data merge block 1 101 -104 {Text3:"{\"text\":\"Ideal\",\"bold\":true,\"color\":\"gold\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/tellraw @p [{\\\"text\\\":\\\"Ideal\\\",\\\"bold\\\":\\\"true\\\",\\\"color\\\":\\\"aqua\\\"},{\\\"text\\\":\\\"- Puts you at specific pre-calculated positions each time to try and ensure that you always get enough velocity to kill the dragon. This isn't realistic, but makes it consistent for practicing timing.\\\",\\\"color\\\":\\\"gold\\\",\\\"bold\\\":\\\"false\\\"}]\"}}"}
execute if block 1 102 -104 #minecraft:buttons[powered=true] if score bPM goofy matches 1 run data merge block 1 101 -104 {Text3:"{\"text\":\"Standard\",\"bold\":\"true\",\"color\":\"gold\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/tellraw @p [{\\\"text\\\":\\\"Standard\\\",\\\"bold\\\":\\\"true\\\",\\\"color\\\":\\\"aqua\\\"},{\\\"text\\\":\\\"- Puts you in the same general spots each time, so there's no guarantee that you get enough velocity. This is much closer to what real setups might look like, but the success rate might still be higher since the dragon hasn't had much time to deviate from its path.\\\",\\\"color\\\":\\\"gold\\\",\\\"bold\\\":\\\"false\\\"}]\"}}"}

execute if block 1 102 -100 #minecraft:buttons[powered=true] if score bDI goofy matches 0 run setblock 1 102 -100 crimson_button[facing=west]
execute if block 1 102 -102 #minecraft:buttons[powered=true] if score bSV goofy matches 0 run setblock 1 102 -102 crimson_button[facing=west]
execute if block -1 102 -100 #minecraft:buttons[powered=true] if score bPH goofy matches 0 run setblock -1 102 -100 crimson_button[facing=east]
execute if block -1 102 -102 #minecraft:buttons[powered=true] if score bFD goofy matches 0 run setblock -1 102 -102 crimson_button[facing=east]
execute if block -1 102 -104 #minecraft:buttons[powered=true] if score bAD goofy matches 0 run setblock -1 102 -104 crimson_button[facing=east]
execute if block 1 102 -100 #minecraft:buttons[powered=true] if score bDI goofy matches 1 run setblock 1 102 -100 warped_button[facing=west]
execute if block 1 102 -102 #minecraft:buttons[powered=true] if score bSV goofy matches 1 run setblock 1 102 -102 warped_button[facing=west]
execute if block -1 102 -100 #minecraft:buttons[powered=true] if score bPH goofy matches 1 run setblock -1 102 -100 warped_button[facing=east]
execute if block -1 102 -102 #minecraft:buttons[powered=true] if score bFD goofy matches 1 run setblock -1 102 -102 warped_button[facing=east]
execute if block -1 102 -104 #minecraft:buttons[powered=true] if score bAD goofy matches 1 run setblock -1 102 -104 warped_button[facing=east]
execute if block 1 102 -104 #minecraft:buttons[powered=true] run setblock 1 102 -104 polished_blackstone_button[facing=west]