#figure out arrow stats

#timing test for shooting early/late
scoreboard players operation tempTime goofy = timing goofy
execute if score timing goofy matches ..-1 run scoreboard players operation tempTime goofy *= -1 goofy
execute if score timing goofy matches 1 run tellraw @p [{"text":"Shot ","color":"gold"},{"text":"1","bold":"true","color":"aqua"},{"text":" tick too ","color":"gold"},{"text":"early!","color":"yellow"}]
execute if score timing goofy matches 2..80 run tellraw @p [{"text":"Shot ","color":"gold"},{"score":{"name":"tempTime","objective":"goofy"},"bold":"true","color":"aqua"},{"text":" ticks too ","color":"gold"},{"text":"early!","color":"yellow"}]
execute if score timing goofy matches -1 run tellraw @p [{"text":"Shot ","color":"gold"},{"text":"1","bold":"true","color":"aqua"},{"text":" tick too ","color":"gold"},{"text":"late!","color":"red"}]
execute if score timing goofy matches -80..-2 run tellraw @p [{"text":"Shot ","color":"gold"},{"score":{"name":"tempTime","objective":"goofy"},"bold":"true","color":"aqua"},{"text":" ticks too ","color":"gold"},{"text":"late!","color":"red"}]
execute if score timing goofy matches 0 run tellraw @p [{"text":"Perfect Timing!","color":"green"}]
execute if score bAD goofy matches 1 run tag @s add arrowed

#how many hitboxes could this have hit?
#assuming arrow with 0 vertical velocity(which is essentially true when you have 400+ velocity)
#so basically is the arrow Y coord within .3(for projectile hitbox) of the Y bounds of several hitboxes
scoreboard players set potH goofy 0
execute store result score aHX goofy run data get entity @s Pos[0] 1000
execute store result score aHZ goofy run data get entity @s Pos[2] 1000
execute store result score aV goofy run data get entity @s Pos[1] 100000
tag @e[tag=orderOffset] remove orderOffset
tag @e[type=ender_dragon,limit=2,sort=arbitrary] add orderOffset
kill @e[tag=colTest]
execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["bottomAngle"]}
execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["topAngle"]}

#neck y test and hit % calc
execute as @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] store result score @s goofy run data get entity @s Pos[1] 100000
scoreboard players remove @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] goofy 30000
execute as @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] run scoreboard players operation @s goofy -= aV goofy
execute as @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] if score @s goofy matches -360000..0 run tag @s add weekend
execute as @e[tag=weekend] run scoreboard players add potH goofy 1
execute if entity @e[tag=weekend] run function mm:calcangles/getheadangles


#tails/wings y test and hit % calc
tag @e[type=ender_dragon,limit=2,sort=arbitrary,tag=!orderOffset] add orderOffset
execute as @e[type=ender_dragon,limit=5,sort=arbitrary,tag=!orderOffset] store result score @s goofy run data get entity @s Pos[1] 100000
scoreboard players remove @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] goofy 30000
execute as @e[type=ender_dragon,limit=5,sort=arbitrary,tag=!orderOffset] run scoreboard players operation @s goofy -= aV goofy
execute as @e[type=ender_dragon,limit=5,sort=arbitrary,tag=!orderOffset] if score @s goofy matches -260000..0 run tag @s add weekend
execute as @e[tag=weekend] run scoreboard players add potH goofy 1
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add leave
tag @e[tag=leave] add tail0
execute if entity @e[tag=weekend,tag=tail0] run function mm:calcangles/gettailangles
tag @e[tag=tail0] remove tail0
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add orderOffset
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add leave
tag @e[tag=leave] add tail1
execute if entity @e[tag=weekend,tag=tail1] run function mm:calcangles/gettailangles
tag @e[tag=tail1] remove tail1
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add orderOffset
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add leave
tag @e[tag=leave] add tail2
execute if entity @e[tag=weekend,tag=tail2] run function mm:calcangles/gettailangles
tag @e[tag=tail2] remove tail2
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add orderOffset
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add leave
tag @e[tag=leave] add wing0
execute if entity @e[tag=weekend,tag=wing0] run function mm:calcangles/getwingangles
tag @e[tag=wing0] remove wing0
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add orderOffset
tag @e[type=ender_dragon,limit=1,sort=arbitrary,tag=!orderOffset] add leave
tag @e[tag=leave] add wing1
execute if entity @e[tag=weekend,tag=wing1] run function mm:calcangles/getwingangles
tag @e[tag=wing1] remove wing1
tag @e[tag=weekend] remove weekend

#combine angle ranges to prevent overlap double counting ???
#this is a very bad way to do this but I can't be bothered to figure out the socially acceptable way to do it
execute as @e[tag=!endingBlinksH,tag=endingBlinksT0] run function mm:calcangles/mergewithhead
execute as @e[tag=!endingBlinksH,tag=endingBlinksT1] run function mm:calcangles/mergewithhead
execute as @e[tag=!endingBlinksH,tag=endingBlinksT2] run function mm:calcangles/mergewithhead
execute as @e[tag=!endingBlinksH,tag=endingBlinksW0] run function mm:calcangles/mergewithhead
execute as @e[tag=!endingBlinksH,tag=endingBlinksW1] run function mm:calcangles/mergewithhead
execute as @e[tag=!endingBlinksT0,tag=endingBlinksH] run function mm:calcangles/mergewithtail0
execute as @e[tag=!endingBlinksT0,tag=endingBlinksT1] run function mm:calcangles/mergewithtail0
execute as @e[tag=!endingBlinksT0,tag=endingBlinksT2] run function mm:calcangles/mergewithtail0
execute as @e[tag=!endingBlinksT0,tag=endingBlinksW0] run function mm:calcangles/mergewithtail0
execute as @e[tag=!endingBlinksT0,tag=endingBlinksW1] run function mm:calcangles/mergewithtail0
execute as @e[tag=!endingBlinksT1,tag=endingBlinksH] run function mm:calcangles/mergewithtail1
execute as @e[tag=!endingBlinksT1,tag=endingBlinksT0] run function mm:calcangles/mergewithtail1
execute as @e[tag=!endingBlinksT1,tag=endingBlinksT2] run function mm:calcangles/mergewithtail1
execute as @e[tag=!endingBlinksT1,tag=endingBlinksW0] run function mm:calcangles/mergewithtail1
execute as @e[tag=!endingBlinksT1,tag=endingBlinksW1] run function mm:calcangles/mergewithtail1
execute as @e[tag=!endingBlinksT2,tag=endingBlinksH] run function mm:calcangles/mergewithtail2
execute as @e[tag=!endingBlinksT2,tag=endingBlinksT0] run function mm:calcangles/mergewithtail2
execute as @e[tag=!endingBlinksT2,tag=endingBlinksT1] run function mm:calcangles/mergewithtail2
execute as @e[tag=!endingBlinksT2,tag=endingBlinksW0] run function mm:calcangles/mergewithtail2
execute as @e[tag=!endingBlinksT2,tag=endingBlinksW1] run function mm:calcangles/mergewithtail2
execute as @e[tag=!endingBlinksW0,tag=endingBlinksH] run function mm:calcangles/mergewithwing0
execute as @e[tag=!endingBlinksW0,tag=endingBlinksT0] run function mm:calcangles/mergewithwing0
execute as @e[tag=!endingBlinksW0,tag=endingBlinksT1] run function mm:calcangles/mergewithwing0
execute as @e[tag=!endingBlinksW0,tag=endingBlinksT2] run function mm:calcangles/mergewithwing0
execute as @e[tag=!endingBlinksW0,tag=endingBlinksW1] run function mm:calcangles/mergewithwing0
execute as @e[tag=!endingBlinksW1,tag=endingBlinksH] run function mm:calcangles/mergewithwing1
execute as @e[tag=!endingBlinksW1,tag=endingBlinksT0] run function mm:calcangles/mergewithwing1
execute as @e[tag=!endingBlinksW1,tag=endingBlinksT1] run function mm:calcangles/mergewithwing1
execute as @e[tag=!endingBlinksW1,tag=endingBlinksT2] run function mm:calcangles/mergewithwing1
execute as @e[tag=!endingBlinksW1,tag=endingBlinksW0] run function mm:calcangles/mergewithwing1

scoreboard players set perH goofy 0
execute as @e[tag=endingBlinks] run scoreboard players operation @s silly -= @s goofy
scoreboard players operation perH goofy += @e[tag=endingBlinks] silly
scoreboard players operation perH goofy *= 100 goofy
scoreboard players operation perH goofy /= 360 goofy

execute if score bPH goofy matches 1.. run tellraw @p [{"text":"Could have hit ","color":"gold"},{"score":{"name":"potH","objective":"goofy"},"color":"aqua","bold":"true"},{"text":"/6 ","color":"aqua","bold":"true"},{"text":"hitboxes! (","color":"gold"},{"score":{"name":"perH","objective":"goofy"},"color":"aqua","bold":"true"},{"text":"%)","color":"gold"}]

#calculate arrow damage if we want to
execute as @s[tag=arrowed] run function mm:calcarrowdamage


tag @s add arrowed