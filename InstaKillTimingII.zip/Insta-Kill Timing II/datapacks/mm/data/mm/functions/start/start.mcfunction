#idk just copied logic from oreo cycle map cuz hashtag lazy and can't get brain to brain lately

kill @e[type=minecraft:ender_dragon]
kill @e[type=minecraft:area_effect_cloud]
setblock 0 102 -99 minecraft:crimson_button[facing=north]
gamemode survival @p
summon area_effect_cloud 0. 0 0. {Tags:["bloodstains"]}
execute store result score angle goofy run data get entity @e[tag=bloodstains,limit=1] UUID[0]
execute store result score veneer goofy run data get entity @e[tag=bloodstains,limit=1] UUID[1]
scoreboard players operation angle goofy %= 360 goofy
summon ender_dragon 0. 128 0. {DragonPhase:1}
execute store result entity @e[type=ender_dragon,limit=1] Rotation[0] float 1 run scoreboard players get angle goofy

execute if score bPM goofy matches 0 run function mm:start/setuptiming
execute if score bPM goofy matches 1 run function mm:start/setupstandard

#poopie inv thing idk how you're supposed to make these
clear @p
execute at @p run summon minecraft:chest_minecart ~ ~ ~ {Tags:["Bathtub"],Items:[{id:"gray_stained_glass_pane",Slot:0,Count:1,tag:{sink:0,blinks:1}},{id:"gray_stained_glass_pane",Slot:1,Count:1,tag:{sink:1,blinks:1}},{id:"gray_stained_glass_pane",Slot:2,Count:1,tag:{sink:2,blinks:1}},{id:"gray_stained_glass_pane",Slot:3,Count:1,tag:{sink:3,blinks:1}},{id:"gray_stained_glass_pane",Slot:4,Count:1,tag:{sink:4,blinks:1}},{id:"gray_stained_glass_pane",Slot:5,Count:1,tag:{sink:5,blinks:1}},{id:"gray_stained_glass_pane",Slot:6,Count:1,tag:{sink:6,blinks:1}},{id:"gray_stained_glass_pane",Slot:7,Count:1,tag:{sink:7,blinks:1}},{id:"gray_stained_glass_pane",Slot:8,Count:1,tag:{sink:8,blinks:1}},{id:"gray_stained_glass_pane",Slot:9,Count:1,tag:{sink:9,blinks:1}},{id:"gray_stained_glass_pane",Slot:10,Count:1,tag:{sink:10,blinks:1}},{id:"gray_stained_glass_pane",Slot:11,Count:1,tag:{sink:11,blinks:1}},{id:"gray_stained_glass_pane",Slot:12,Count:1,tag:{sink:12,blinks:1}},{id:"gray_stained_glass_pane",Slot:13,Count:1,tag:{sink:13,blinks:1}},{id:"gray_stained_glass_pane",Slot:14,Count:1,tag:{sink:14,blinks:1}},{id:"gray_stained_glass_pane",Slot:15,Count:1,tag:{sink:15,blinks:1}},{id:"gray_stained_glass_pane",Slot:16,Count:1,tag:{sink:16,blinks:1}},{id:"gray_stained_glass_pane",Slot:17,Count:1,tag:{sink:17,blinks:1}},{id:"gray_stained_glass_pane",Slot:18,Count:1,tag:{sink:18,blinks:1}},{id:"gray_stained_glass_pane",Slot:19,Count:1,tag:{sink:19,blinks:1}},{id:"gray_stained_glass_pane",Slot:20,Count:1,tag:{sink:20,blinks:1}},{id:"gray_stained_glass_pane",Slot:21,Count:1,tag:{sink:21,blinks:1}},{id:"gray_stained_glass_pane",Slot:22,Count:1,tag:{sink:22,blinks:1}},{id:"gray_stained_glass_pane",Slot:23,Count:1,tag:{sink:23,blinks:1}},{id:"gray_stained_glass_pane",Slot:24,Count:1,tag:{sink:24,blinks:1}},{id:"gray_stained_glass_pane",Slot:25,Count:1,tag:{sink:25,blinks:1}},{id:"gray_stained_glass_pane",Slot:26,Count:1,tag:{sink:26,blinks:1}}]}
data modify entity @e[tag=Bathtub,limit=1] Items append from block 0 101 -98 Items[]
kill @e[tag=Bathtub]