#realistic coords
#basically just the two best spots to stand in and thats it. one for cw dragon one for ccw dragon. I would maybe seperate by fast and slow but I think these rates are already better than normal because we're so close to the start of dragon spawn(?)

execute if score angle goofy matches 0..43 run summon area_effect_cloud 26.3937 1 -28.2648 {Duration:42069420,Tags:["vomit"]}
execute if score angle goofy matches 44..109 run summon area_effect_cloud 27.3069 1 -27.3683 {Duration:42069420,Tags:["vomit"]}
execute if score angle goofy matches 110..223 run summon area_effect_cloud 26.3937 1 -28.2648 {Duration:42069420,Tags:["vomit"]}
execute if score angle goofy matches 224..338 run summon area_effect_cloud 27.3069 1 -27.3683 {Duration:42069420,Tags:["vomit"]}
execute if score angle goofy matches 339.. run summon area_effect_cloud 26.3937 1 -28.2648 {Duration:42069420,Tags:["vomit"]}
execute if score angle goofy matches 182..266 as @e[tag=vomit,limit=1] at @s run tp @s ~ ~-1 ~

#slight offset for ??? imperfection
scoreboard players operation erd goofy = veneer goofy
scoreboard players operation erd goofy %= 3600 goofy
execute store result entity @e[tag=vomit,limit=1] Rotation[0] float .1 run scoreboard players get erd goofy
scoreboard players operation veneer goofy /= 3600 goofy
scoreboard players operation ard goofy = veneer goofy
scoreboard players operation ard goofy %= 10 goofy
execute if score ard goofy matches 1.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 2.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 3.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 4.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 5.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 6.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 7.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 8.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015
execute if score ard goofy matches 9.. as @e[tag=vomit,limit=1] at @s run tp @s ^ ^ ^.0015


#how long does each angle take to get to that point?
#could prolly calc this on the fly but this is easier
execute if score angle goofy matches 0..5 run scoreboard players set timing goofy 139
execute if score angle goofy matches 6..9 run scoreboard players set timing goofy 138
execute if score angle goofy matches 10..30 run scoreboard players set timing goofy 139
execute if score angle goofy matches 31..56 run scoreboard players set timing goofy 140
execute if score angle goofy matches 57..100 run scoreboard players set timing goofy 139
execute if score angle goofy matches 101..103 run scoreboard players set timing goofy 140
execute if score angle goofy matches 104..109 run scoreboard players set timing goofy 141
execute if score angle goofy matches 110..113 run scoreboard players set timing goofy 142
execute if score angle goofy matches 114..118 run scoreboard players set timing goofy 141
execute if score angle goofy matches 119..149 run scoreboard players set timing goofy 140
execute if score angle goofy matches 150..159 run scoreboard players set timing goofy 141
execute if score angle goofy matches 160..165 run scoreboard players set timing goofy 142
execute if score angle goofy matches 166..171 run scoreboard players set timing goofy 143
execute if score angle goofy matches 172..176 run scoreboard players set timing goofy 144
execute if score angle goofy matches 177..181 run scoreboard players set timing goofy 145
execute if score angle goofy matches 182..186 run scoreboard players set timing goofy 146
execute if score angle goofy matches 187..191 run scoreboard players set timing goofy 147
execute if score angle goofy matches 192..195 run scoreboard players set timing goofy 148
execute if score angle goofy matches 196..200 run scoreboard players set timing goofy 149
execute if score angle goofy matches 201..204 run scoreboard players set timing goofy 150
execute if score angle goofy matches 205..208 run scoreboard players set timing goofy 151
execute if score angle goofy matches 209..212 run scoreboard players set timing goofy 152
execute if score angle goofy matches 213..216 run scoreboard players set timing goofy 153
execute if score angle goofy matches 217..220 run scoreboard players set timing goofy 154
execute if score angle goofy matches 221..227 run scoreboard players set timing goofy 155
execute if score angle goofy matches 228..231 run scoreboard players set timing goofy 154
execute if score angle goofy matches 232..235 run scoreboard players set timing goofy 153
execute if score angle goofy matches 236..239 run scoreboard players set timing goofy 152
execute if score angle goofy matches 240..243 run scoreboard players set timing goofy 151
execute if score angle goofy matches 244..247 run scoreboard players set timing goofy 150
execute if score angle goofy matches 248..252 run scoreboard players set timing goofy 149
execute if score angle goofy matches 253..256 run scoreboard players set timing goofy 148
execute if score angle goofy matches 257..261 run scoreboard players set timing goofy 147
execute if score angle goofy matches 262..266 run scoreboard players set timing goofy 146
execute if score angle goofy matches 267..271 run scoreboard players set timing goofy 145
execute if score angle goofy matches 272..276 run scoreboard players set timing goofy 144
execute if score angle goofy matches 277..282 run scoreboard players set timing goofy 143
execute if score angle goofy matches 283..288 run scoreboard players set timing goofy 142
execute if score angle goofy matches 289..298 run scoreboard players set timing goofy 141
execute if score angle goofy matches 299..329 run scoreboard players set timing goofy 140
execute if score angle goofy matches 330..334 run scoreboard players set timing goofy 141
execute if score angle goofy matches 335..338 run scoreboard players set timing goofy 142
execute if score angle goofy matches 339..344 run scoreboard players set timing goofy 141
execute if score angle goofy matches 345..347 run scoreboard players set timing goofy 140
execute if score angle goofy matches 348..359 run scoreboard players set timing goofy 139

#create platform and tp player
execute at @e[tag=vomit,limit=1] run fill ~ ~115 ~ ~ ~117 ~ cobblestone
execute at @e[tag=vomit,limit=1] run tp @p ~ ~118 ~ facing 0. 128 0.
execute as @e[tag=vomit,limit=1] at @s run tp @s ~ 0 ~