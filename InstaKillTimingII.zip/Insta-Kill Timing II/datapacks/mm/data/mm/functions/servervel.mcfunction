#keep track of and display server velocity for funsies ig idk
execute store result score vX goofy run data get entity @p Motion[0] 1000
execute store result score vY goofy run data get entity @p Motion[1] 1000
execute store result score vZ goofy run data get entity @p Motion[2] 1000
#seperate into components for display
#this is a horrible way to do this but i don't feel like making it 3242857894 digits or dealing with a geosquare igt reference god i feel so old saying that how was everything 5+ years ago what even happened 
scoreboard players operation dX goofy = vX goofy
execute if score vX goofy matches ..0 run scoreboard players operation dX goofy *= -1 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 1000 goofy
scoreboard players operation oX goofy *= 1000 goofy
scoreboard players operation tX goofy = dX goofy
scoreboard players operation tX goofy -= oX goofy
scoreboard players operation tX goofy /= 100 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 100 goofy
scoreboard players operation oX goofy *= 100 goofy
scoreboard players operation hX goofy = dX goofy
scoreboard players operation hX goofy -= oX goofy
scoreboard players operation hX goofy /= 10 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 10 goofy
scoreboard players operation oX goofy *= 10 goofy
scoreboard players operation thX goofy = dX goofy
scoreboard players operation thX goofy -= oX goofy
scoreboard players operation dX goofy /= 1000 goofy
scoreboard players operation dY goofy = vY goofy
execute if score vY goofy matches ..0 run scoreboard players operation dY goofy *= -1 goofy
scoreboard players operation oY goofy = dY goofy
scoreboard players operation oY goofy /= 1000 goofy
scoreboard players operation oY goofy *= 1000 goofy
scoreboard players operation tY goofy = dY goofy
scoreboard players operation tY goofy -= oY goofy
scoreboard players operation tY goofy /= 100 goofy
scoreboard players operation oY goofy = dY goofy
scoreboard players operation oY goofy /= 100 goofy
scoreboard players operation oY goofy *= 100 goofy
scoreboard players operation hY goofy = dY goofy
scoreboard players operation hY goofy -= oY goofy
scoreboard players operation hY goofy /= 10 goofy
scoreboard players operation oY goofy = dY goofy
scoreboard players operation oY goofy /= 10 goofy
scoreboard players operation oY goofy *= 10 goofy
scoreboard players operation thY goofy = dY goofy
scoreboard players operation thY goofy -= oY goofy
scoreboard players operation dY goofy /= 1000 goofy
scoreboard players operation dZ goofy = vZ goofy
execute if score vZ goofy matches ..0 run scoreboard players operation dZ goofy *= -1 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 1000 goofy
scoreboard players operation oZ goofy *= 1000 goofy
scoreboard players operation tZ goofy = dZ goofy
scoreboard players operation tZ goofy -= oZ goofy
scoreboard players operation tZ goofy /= 100 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 100 goofy
scoreboard players operation oZ goofy *= 100 goofy
scoreboard players operation hZ goofy = dZ goofy
scoreboard players operation hZ goofy -= oZ goofy
scoreboard players operation hZ goofy /= 10 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 10 goofy
scoreboard players operation oZ goofy *= 10 goofy
scoreboard players operation thZ goofy = dZ goofy
scoreboard players operation thZ goofy -= oZ goofy
scoreboard players operation dZ goofy /= 1000 goofy


#display
execute if score vX goofy matches ..-1 if score vY goofy matches ..-1 if score vZ goofy matches ..-1 run title @a actionbar ["Server Vel: -",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches ..-1 if score vY goofy matches ..-1 if score vZ goofy matches 0.. run title @a actionbar ["Server Vel: -",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches ..-1 if score vY goofy matches 0.. if score vZ goofy matches ..-1 run title @a actionbar ["Server Vel: -",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches ..-1 if score vY goofy matches 0.. if score vZ goofy matches 0.. run title @a actionbar ["Server Vel: -",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches 0.. if score vY goofy matches ..-1 if score vZ goofy matches ..-1 run title @a actionbar ["Server Vel: ",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches 0.. if score vY goofy matches ..-1 if score vZ goofy matches 0.. run title @a actionbar ["Server Vel: ",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches 0.. if score vY goofy matches 0.. if score vZ goofy matches ..-1 run title @a actionbar ["Server Vel: ",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]
execute if score vX goofy matches 0.. if score vY goofy matches 0.. if score vZ goofy matches 0.. run title @a actionbar ["Server Vel: ",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dY","objective":"goofy"}},".",{"score":{"name":"tY","objective":"goofy"}},{"score":{"name":"hY","objective":"goofy"}},{"score":{"name":"thY","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}}]