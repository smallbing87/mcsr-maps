#tickle spot distance thing
tag @e[tag=orderOffset] remove orderOffset
tag @e[type=ender_dragon,limit=3,sort=arbitrary] add orderOffset
execute store result score tsX goofy run data get entity @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] Pos[0] 1000
execute store result score tsZ goofy run data get entity @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] Pos[2] 1000
execute store result score pX goofy run data get entity @p Pos[0] 1000
execute store result score pZ goofy run data get entity @p Pos[2] 1000
scoreboard players operation pX goofy -= tsX goofy
scoreboard players operation pZ goofy -= tsZ goofy
scoreboard players operation pX goofy *= pX goofy
scoreboard players operation pZ goofy *= pZ goofy
scoreboard players operation tD goofy = pX goofy
scoreboard players operation tD goofy += pZ goofy
scoreboard players operation tD goofy /= 100 goofy
#lazy sqrt.....
scoreboard players set sqrtD goofy 40
scoreboard players set sqrtN goofy 400
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += tD goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy


scoreboard players operation tD goofy = sqrtN goofy

scoreboard players operation oTD goofy = sqrtN goofy
scoreboard players operation oTD goofy /= 100 goofy
scoreboard players operation oTD goofy *= 100 goofy
scoreboard players operation tTD goofy = sqrtN goofy
scoreboard players operation tTD goofy -= oTD goofy
scoreboard players operation tTD goofy /= 10 goofy
scoreboard players operation oTD goofy = sqrtN goofy
scoreboard players operation oTD goofy /= 10 goofy
scoreboard players operation oTD goofy *= 10 goofy
scoreboard players operation hTD goofy = sqrtN goofy
scoreboard players operation hTD goofy -= oTD goofy
scoreboard players operation sqrtN goofy /= 100 goofy

#seperate and print coords of spot

scoreboard players operation dX goofy = tsX goofy
execute if score tsX goofy matches ..0 run scoreboard players operation dX goofy *= -1 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 1000 goofy
scoreboard players operation oX goofy *= 1000 goofy
scoreboard players operation tX goofy = dX goofy
scoreboard players operation tX goofy -= oX goofy
scoreboard players operation tX goofy /= 100 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 100 goofy
scoreboard players operation oX goofy *= 100 goofy
scoreboard players operation hX goofy = dX goofy
scoreboard players operation hX goofy -= oX goofy
scoreboard players operation hX goofy /= 10 goofy
scoreboard players operation oX goofy = dX goofy
scoreboard players operation oX goofy /= 10 goofy
scoreboard players operation oX goofy *= 10 goofy
scoreboard players operation thX goofy = dX goofy
scoreboard players operation thX goofy -= oX goofy
scoreboard players operation dX goofy /= 1000 goofy
scoreboard players operation dZ goofy = tsZ goofy
execute if score tsZ goofy matches ..0 run scoreboard players operation dZ goofy *= -1 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 1000 goofy
scoreboard players operation oZ goofy *= 1000 goofy
scoreboard players operation tZ goofy = dZ goofy
scoreboard players operation tZ goofy -= oZ goofy
scoreboard players operation tZ goofy /= 100 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 100 goofy
scoreboard players operation oZ goofy *= 100 goofy
scoreboard players operation hZ goofy = dZ goofy
scoreboard players operation hZ goofy -= oZ goofy
scoreboard players operation hZ goofy /= 10 goofy
scoreboard players operation oZ goofy = dZ goofy
scoreboard players operation oZ goofy /= 10 goofy
scoreboard players operation oZ goofy *= 10 goofy
scoreboard players operation thZ goofy = dZ goofy
scoreboard players operation thZ goofy -= oZ goofy
scoreboard players operation dZ goofy /= 1000 goofy

execute if score tsX goofy matches ..-1 if score tsZ goofy matches ..-1 at @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] run tellraw @a[distance=..7] ["Dist: ",{"score":{"name":"sqrtN","objective":"goofy"}},".",{"score":{"name":"tTD","objective":"goofy"}},{"score":{"name":"hTD","objective":"goofy"}}," (-",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}},")"]
execute if score tsX goofy matches ..-1 if score tsZ goofy matches 0.. at @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] run tellraw @a[distance=..7] ["Dist: ",{"score":{"name":"sqrtN","objective":"goofy"}},".",{"score":{"name":"tTD","objective":"goofy"}},{"score":{"name":"hTD","objective":"goofy"}}," (-",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}},")"]
execute if score tsX goofy matches 0.. if score tsZ goofy matches ..-1 at @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] run tellraw @a[distance=..7] ["Dist: ",{"score":{"name":"sqrtN","objective":"goofy"}},".",{"score":{"name":"tTD","objective":"goofy"}},{"score":{"name":"hTD","objective":"goofy"}}," (",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", -",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}},")"]
execute if score tsX goofy matches 0.. if score tsZ goofy matches 0.. at @e[tag=!orderOffset,type=minecraft:ender_dragon,limit=1,sort=arbitrary] run tellraw @a[distance=..7] ["Dist: ",{"score":{"name":"sqrtN","objective":"goofy"}},".",{"score":{"name":"tTD","objective":"goofy"}},{"score":{"name":"hTD","objective":"goofy"}}," (",{"score":{"name":"dX","objective":"goofy"}},".",{"score":{"name":"tX","objective":"goofy"}},{"score":{"name":"hX","objective":"goofy"}},{"score":{"name":"thX","objective":"goofy"}},", ",{"score":{"name":"dZ","objective":"goofy"}},".",{"score":{"name":"tZ","objective":"goofy"}},{"score":{"name":"hZ","objective":"goofy"}},{"score":{"name":"thZ","objective":"goofy"}},")"]