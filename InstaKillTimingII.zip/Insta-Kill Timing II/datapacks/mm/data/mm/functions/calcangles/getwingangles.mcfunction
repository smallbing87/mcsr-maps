#calculate angles that would hit a wing
execute as @e[tag=leave] store result score sqX goofy run data get entity @s Pos[0] 1000
execute as @e[tag=leave] store result score sqZ goofy run data get entity @s Pos[2] 1000
scoreboard players operation sqX goofy -= aHX goofy
scoreboard players operation sqZ goofy -= aHZ goofy
execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["endingBlinks","endingBlinksW"]}
scoreboard players add sqX goofy 2300
scoreboard players add sqZ goofy 2300
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=topAngle] ~2.3 ~ ~2.3
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=bottomAngle] ~2.3 ~ ~2.3
scoreboard players remove sqX goofy 4600
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=topAngle] ~-2.3 ~ ~2.3
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=bottomAngle] ~-2.3 ~ ~2.3
scoreboard players remove sqZ goofy 4600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=topAngle] ~-2.3 ~ ~-2.3
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=bottomAngle] ~-2.3 ~ ~-2.3
scoreboard players add sqX goofy 4600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=topAngle] ~2.3 ~ ~-2.3
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=bottomAngle] ~2.3 ~ ~-2.3
execute at @s facing entity @e[tag=bottomAngle] feet run tp @e[tag=endingBlinksW] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksW,limit=1] goofy run data get entity @e[tag=endingBlinksW,limit=1] Rotation[0] 1
execute at @s facing entity @e[tag=topAngle,limit=1] feet run tp @e[tag=endingBlinksW,limit=1] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksW,limit=1] silly run data get entity @e[tag=endingBlinksW,limit=1] Rotation[0] 1
execute as @e[tag=endingBlinksW,limit=1] if score @s goofy matches ..-1 run scoreboard players add @s goofy 360
execute as @e[tag=endingBlinksW,limit=1] if score @s silly matches ..-1 run scoreboard players add @s silly 360
execute as @e[tag=endingBlinksW,limit=1] if score @s silly < @s goofy run scoreboard players add @s silly 360
execute if entity @e[tag=wing0] run tag @e[tag=endingBlinksW] add endingBlinksW0
execute if entity @e[tag=wing1] run tag @e[tag=endingBlinksW] add endingBlinksW1
tag @e[tag=endingBlinksW] remove endingBlinksW
tag @e[tag=leave] remove leave