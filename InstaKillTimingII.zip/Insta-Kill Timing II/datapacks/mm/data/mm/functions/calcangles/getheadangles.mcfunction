#calculate angles that would hit head
execute as @e[tag=weekend] store result score sqX goofy run data get entity @s Pos[0] 1000
execute as @e[tag=weekend] store result score sqZ goofy run data get entity @s Pos[2] 1000
scoreboard players operation sqX goofy -= aHX goofy
scoreboard players operation sqZ goofy -= aHZ goofy
execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["endingBlinks","endingBlinksH"]}
scoreboard players add sqX goofy 1800
scoreboard players add sqZ goofy 1800
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=weekend] run tp @e[tag=topAngle] ~1.8 ~ ~1.8
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=weekend] run tp @e[tag=bottomAngle] ~1.8 ~ ~1.8
scoreboard players remove sqX goofy 3600
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=weekend] run tp @e[tag=topAngle] ~-1.8 ~ ~1.8
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=weekend] run tp @e[tag=bottomAngle] ~-1.8 ~ ~1.8
scoreboard players remove sqZ goofy 3600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=weekend] run tp @e[tag=topAngle] ~-1.8 ~ ~-1.8
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=weekend] run tp @e[tag=bottomAngle] ~-1.8 ~ ~-1.8
scoreboard players add sqX goofy 3600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=weekend] run tp @e[tag=topAngle] ~1.8 ~ ~-1.8
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=weekend] run tp @e[tag=bottomAngle] ~1.8 ~ ~-1.8
execute at @s facing entity @e[tag=bottomAngle] feet run tp @e[tag=endingBlinksH] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksH,limit=1] goofy run data get entity @e[tag=endingBlinksH,limit=1] Rotation[0] 1
execute at @s facing entity @e[tag=topAngle,limit=1] feet run tp @e[tag=endingBlinksH,limit=1] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksH,limit=1] silly run data get entity @e[tag=endingBlinksH,limit=1] Rotation[0] 1
execute as @e[tag=endingBlinksH,limit=1] if score @s goofy matches ..-1 run scoreboard players add @s goofy 360
execute as @e[tag=endingBlinksH,limit=1] if score @s silly matches ..-1 run scoreboard players add @s silly 360
execute as @e[tag=endingBlinksH,limit=1] if score @s silly < @s goofy run scoreboard players add @s silly 360
tag @e[tag=weekend] remove weekend