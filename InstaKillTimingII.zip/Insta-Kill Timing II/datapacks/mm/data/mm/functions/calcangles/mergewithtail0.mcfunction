#check and merge @s range with tail0 range
#i'm probably missing some edge cases but i cannot physically wrap my head around angles(get it)
#if you've gotten this far feel free to fix it for me mwuh :)
#wrap test
scoreboard players set btmm goofy -1000
scoreboard players set ttmm goofy -1000
execute if score @e[tag=endingBlinksT0,limit=1] silly < @e[tag=endingBlinksT0,limit=1] goofy run tag @e[tag=endingBlinksT0,limit=1] add wrapped
execute if score @s silly < @s goofy run tag @s add wrappeds
#wrapping cancels out maybe?
execute unless entity @e[tag=wrapped] unless entity @e[tag=wrappeds] if score @s goofy <= @e[tag=endingBlinksT0,limit=1] silly if score @e[tag=endingBlinksT0,limit=1] goofy <= @s silly run tag @s add bagsUnpacked
tag @s[tag=bagsUnpacked] add nothingMajor 
execute if entity @e[tag=wrapped] if entity @e[tag=wrappeds] run tag @s add bagsUnpacked
execute if entity @e[tag=wrapped] if entity @e[tag=wrappeds] run tag @s add nothingMajor
#uhhhhhhhhhh wrapping doesn't cancel lord help me
execute if entity @e[tag=wrappeds] unless entity @e[tag=wrapped] if score @e[tag=endingBlinksT0,limit=1] goofy <= @s silly run scoreboard players operation btmm goofy = @s goofy
execute if entity @e[tag=wrappeds] unless entity @e[tag=wrapped] if score @e[tag=endingBlinksT0,limit=1] goofy <= @s silly run tag @s add nothingMajor
execute if entity @e[tag=wrappeds] unless entity @e[tag=wrapped] if score @e[tag=endingBlinksT0,limit=1] silly >= @s goofy run scoreboard players operation ttmm goofy = @s silly
execute if entity @e[tag=wrappeds] unless entity @e[tag=wrapped] if score @e[tag=endingBlinksT0,limit=1] silly >= @s goofy run tag @s add bagsUnpacked
execute if entity @e[tag=wrapped] unless entity @e[tag=wrappeds] if score @s goofy <= @e[tag=endingBlinksT0,limit=1] silly run scoreboard players operation btmm goofy = @e[tag=endingBlinksT0,limit=1] goofy
execute if entity @e[tag=wrapped] unless entity @e[tag=wrappeds] if score @s goofy <= @e[tag=endingBlinksT0,limit=1] silly run tag @s add nothingMajor
execute if entity @e[tag=wrapped] unless entity @e[tag=wrappeds] if score @s silly >= @e[tag=endingBlinksT0,limit=1] goofy run scoreboard players operation ttmm goofy = @e[tag=endingBlinksT0,limit=1] silly
execute if entity @e[tag=wrapped] unless entity @e[tag=wrappeds] if score @s silly >= @e[tag=endingBlinksT0,limit=1] goofy run tag @s add bagsUnpacked
#merge maxes stuff
execute if entity @s[tag=bagsUnpacked] if score @s goofy < @e[tag=endingBlinksT0,limit=1] goofy run scoreboard players operation @e[tag=endingBlinksT0,limit=1] goofy = @s goofy
execute if entity @s[tag=nothingMajor] if score @s silly > @e[tag=endingBlinksT0,limit=1] silly run scoreboard players operation @e[tag=endingBlinksT0,limit=1] silly = @s silly
execute if score ttmm goofy matches -1.. run scoreboard players operation @e[tag=endingBlinksT0,limit=1] silly = ttmm silly
execute if score btmm goofy matches -1.. run scoreboard players operation @e[tag=endingBlinksT0,limit=1] goofy = btmm goofy
tag @e[tag=bagsUnpacked] remove nothingMajor
#merge physical entities so ordering is consistent later
execute if entity @s[tag=bagsUnpacked] run data modify entity @e[tag=endingBlinksT0,limit=1] Tags append from entity @s Tags[]
execute if entity @s[tag=bagsUnpacked] run kill @s
execute if entity @s[tag=nothingMajor] run data modify entity @e[tag=endingBlinksT0,limit=1] Tags append from entity @s Tags[]
execute if entity @s[tag=nothingMajor] run kill @s
tag @e[tag=nothingMajor] remove nothingMajor
tag @e[tag=bagsUnpacked] remove bagsUnpacked
tag @e[tag=wrapped] remove wrapped
tag @e[tag=wrappeds] remove wrappeds