#calculate angles that would hit a tail
execute as @e[tag=leave] store result score sqX goofy run data get entity @s Pos[0] 1000
execute as @e[tag=leave] store result score sqZ goofy run data get entity @s Pos[2] 1000
scoreboard players operation sqX goofy -= aHX goofy
scoreboard players operation sqZ goofy -= aHZ goofy
execute at @s run summon area_effect_cloud ~ ~ ~ {Tags:["endingBlinks","endingBlinksT"]}
scoreboard players add sqX goofy 1300
scoreboard players add sqZ goofy 1300
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=topAngle] ~1.3 ~ ~1.3
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=bottomAngle] ~1.3 ~ ~1.3
scoreboard players remove sqX goofy 2600
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=topAngle] ~-1.3 ~ ~1.3
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=bottomAngle] ~-1.3 ~ ~1.3
scoreboard players remove sqZ goofy 2600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=topAngle] ~-1.3 ~ ~-1.3
execute if score sqX goofy matches 0.. if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=bottomAngle] ~-1.3 ~ ~-1.3
scoreboard players add sqX goofy 2600
execute if score sqX goofy matches ..-1 if score sqZ goofy matches ..-1 at @e[tag=leave] run tp @e[tag=topAngle] ~1.3 ~ ~-1.3
execute if score sqX goofy matches 0.. if score sqZ goofy matches 0.. at @e[tag=leave] run tp @e[tag=bottomAngle] ~1.3 ~ ~-1.3
execute at @s facing entity @e[tag=bottomAngle] feet run tp @e[tag=endingBlinksT] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksT,limit=1] goofy run data get entity @e[tag=endingBlinksT,limit=1] Rotation[0] 1
execute at @s facing entity @e[tag=topAngle,limit=1] feet run tp @e[tag=endingBlinksT,limit=1] ~ ~ ~ ~ ~
execute store result score @e[tag=endingBlinksT,limit=1] silly run data get entity @e[tag=endingBlinksT,limit=1] Rotation[0] 1
execute as @e[tag=endingBlinksT,limit=1] if score @s goofy matches ..-1 run scoreboard players add @s goofy 360
execute as @e[tag=endingBlinksT,limit=1] if score @s silly matches ..-1 run scoreboard players add @s silly 360
execute as @e[tag=endingBlinksT,limit=1] if score @s silly < @s goofy run scoreboard players add @s silly 360
execute if entity @e[tag=tail0] run tag @e[tag=endingBlinksT] add endingBlinksT0
execute if entity @e[tag=tail1] run tag @e[tag=endingBlinksT] add endingBlinksT1
execute if entity @e[tag=tail2] run tag @e[tag=endingBlinksT] add endingBlinksT2
tag @e[tag=endingBlinksT] remove endingBlinksT
tag @e[tag=leave] remove leave