execute in minecraft:the_end if block 0 102 -99 #minecraft:buttons[powered=true] run function mm:start/start
execute as @a[tag=!oneofusoneofus] in minecraft:the_end run function mm:initplayer
clear @p minecraft:gray_stained_glass_pane{blinks:1}
execute in the_end if entity @e[type=egg] run kill @p
execute in the_end as @a[scores={ddddddddddddd=1..}] run function mm:reset

#server velocity display
execute if score bSV goofy matches 1.. run function mm:servervel
#tickle dist
execute if score bDI goofy matches 1.. run function mm:tickledist

#dragon health bar
bossbar set minecraft:dragon players @a
execute in the_end store result bossbar dragon value run data get entity @e[type=minecraft:ender_dragon,limit=1] Health

#timing thingie 
scoreboard players remove timing goofy 1
execute as @e[type=arrow,tag=!arrowed] if entity @e[type=ender_dragon] run function mm:arrowthing

#fun buttons
execute in the_end run function mm:buttons

#move detector
execute if score bFD goofy matches 1.. as @e[tag=vomit,limit=1] at @s run function mm:movedec


#idk
execute in the_end positioned 0.5 101.00 -98.5 if entity @e[type=minecraft:ender_dragon] run kill @a[distance=..5,gamemode=survival]
execute in the_end positioned 0.5 101.00 -98.5 if block 0 61 1 end_portal run kill @a[distance=..5,gamemode=survival]

#dmg thing
scoreboard players operation pDH goofy = dH goofy
execute store result score dH goofy run data get entity @e[type=minecraft:ender_dragon,limit=1] Health
scoreboard players operation pDH goofy -= dH goofy
execute if score pDH goofy matches 1.. if entity @e[type=ender_dragon] run tellraw @p [{"text":"Dragon Damage: ","color":"gold","clickEvent":{"action":"run_command","value":"uwu"},"hoverEvent":{"action":"show_text","value":["",{"text":"don't d it ","color":"white"}]}},{"score":{"name":"pDH","objective":"goofy"},"color":"red"}]

#fun portal
execute if entity @e[type=minecraft:ender_dragon] if data entity @e[type=ender_dragon,limit=1] Health run scoreboard players set dhpruhjfdgsjhgbdfg goofy 0
execute if entity @e[type=minecraft:ender_dragon] unless data entity @e[type=ender_dragon,limit=1] Health run scoreboard players add dhpruhjfdgsjhgbdfg goofy 1
execute if score dhpruhjfdgsjhgbdfg goofy matches 200.. in the_end run fill -2 61 -2 2 61 2 end_portal replace air
execute if score dhpruhjfdgsjhgbdfg goofy matches 200.. run scoreboard players set dhpruhjfdgsjhgbdfg goofy 0