#get damage multiplier from power or whatever
execute store result score add goofy run data get entity @s damage
#combine velocities to get total speed
execute store result score avx goofy run data get entity @s Motion[0] 10
execute store result score avy goofy run data get entity @s Motion[1] 10
execute store result score avz goofy run data get entity @s Motion[2] 10
scoreboard players operation avx goofy *= avx goofy
scoreboard players operation avy goofy *= avy goofy
scoreboard players operation avz goofy *= avz goofy
scoreboard players operation avx goofy += avy goofy
scoreboard players operation avx goofy += avz goofy
#worry about overflow
execute if score avx goofy matches 40000.. run tag @s add over
execute as @s[tag=over] run scoreboard players operation avx goofy /= 100 goofy
#sqrt time poggers
scoreboard players set sqrtD goofy 40
scoreboard players set sqrtN goofy 400
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation sqrtD goofy = sqrtN goofy
scoreboard players operation sqrtD goofy *= 2 goofy
scoreboard players operation sqrtN goofy *= sqrtN goofy
scoreboard players operation sqrtN goofy += avx goofy
scoreboard players operation sqrtN goofy /= sqrtD goofy

scoreboard players operation avx goofy = sqrtN goofy

#arrow and display stuffs
execute as @s[tag=over] run scoreboard players operation avx goofy *= 10 goofy
scoreboard players operation avxs goofy = avx goofy
scoreboard players operation avxst goofy = avx goofy
scoreboard players operation avxs goofy /= 10 goofy
scoreboard players operation avxs goofy *= 10 goofy
scoreboard players operation avxst goofy -= avxs goofy
scoreboard players operation avxs goofy /= 10 goofy
scoreboard players operation avx goofy = avxs goofy
scoreboard players operation avx goofy *= add goofy
scoreboard players operation cad goofy = avx goofy
scoreboard players operation cad goofy /= 2 goofy
scoreboard players operation cad goofy += avx goofy
scoreboard players add cad goofy 2
scoreboard players operation cad goofy /= 4 goofy
scoreboard players operation avx goofy /= 4 goofy
scoreboard players add cad goofy 1
scoreboard players add avx goofy 1

execute unless entity @s[nbt={crit:1b}] run tellraw @p [{"score":{"name":"avxs","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"cat jumpscare\",\"italic\":\"false\"}'}} 1"}},{"text":".","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"me when dragon\",\"italic\":\"false\"}'}} 1"}},{"score":{"name":"avxst","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"you rn\",\"italic\":\"false\"}'}} 1"}},{"text":"m/t (","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"meoww\",\"italic\":\"false\"}'}} 1"}},{"score":{"name":"avx","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\":3 :3\",\"italic\":\"false\"}'}} 1"}},{"text":" dmg)","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"look at this fella like isn\\'t that crazy\",\"italic\":\"false\"}'}} 1"}}]
execute if entity @s[nbt={crit:1b}] run tellraw @p [{"score":{"name":"avxs","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"cat jumpscare\",\"italic\":\"false\"}'}} 1"}},{"text":".","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"me when dragon\",\"italic\":\"false\"}'}} 1"}},{"score":{"name":"avxst","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"you rn\",\"italic\":\"false\"}'}} 1"}},{"text":"m/t (","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"meoww\",\"italic\":\"false\"}'}} 1"}},{"score":{"name":"avx","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\":3 :3\",\"italic\":\"false\"}'}} 1"}},{"text":"-","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"i wanted you to have this\",\"italic\":\"false\"}'}} 1"}},{"score":{"name":"cad","objective":"goofy"},"color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"arrow you when me dragon the lol:\",\"italic\":\"false\"}'}} 1"}},{"text":" dmg)","color":"#FF95FF","clickEvent":{"action":"run_command","value":"/replaceitem entity @p weapon.offhand filled_map{map:0,display:{Name:'{\"text\":\"look at this fella like isn\\'t that crazy\",\"italic\":\"false\"}'}} 1"}}]