kill @e[type=egg]
kill @e[type=ender_dragon]
kill @e[type=area_effect_cloud]
kill @e[type=boat]
kill @e[type=ender_pearl]
kill @e[type=arrow]
kill @e[type=item]
kill @e[type=end_crystal]
kill @e[type=armor_stand]
kill @e[type=experience_orb]
kill @e[type=item_frame]
summon minecraft:end_crystal 12.5 77 -39.5
summon minecraft:end_crystal 33.5 98 -24.5
summon minecraft:end_crystal 42.5 104 0.5
summon minecraft:end_crystal 33.5 89 24.5
summon minecraft:end_crystal 12.5 83 39.5
summon minecraft:end_crystal -12.5 95 39.5
summon minecraft:end_crystal -33.5 86 24.5
summon minecraft:end_crystal -41.5 80 -0.5
summon minecraft:end_crystal -33.5 101 -24.5
summon minecraft:end_crystal -12.5 92 -39.5
fill 20 115 -30 29 125 -23 air
fill -2 61 -2 2 61 2 air replace end_portal
tp @s 0 101. -100 0 5
scoreboard players reset @s ddddddddddddd
setblock 0 63 -1 wall_torch[facing=north]
setblock 0 63 1 wall_torch[facing=south]
setblock -1 63 0 wall_torch[facing=west]
setblock 1 63 0 wall_torch[facing=east]