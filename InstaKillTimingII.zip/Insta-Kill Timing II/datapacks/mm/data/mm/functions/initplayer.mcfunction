tag @s add oneofusoneofus
tp @s 0 101. -100 0 5
spawnpoint @s 0 101 -100
gamemode survival @s
setblock 0 102 -99 minecraft:crimson_button[facing=north]
give @p written_book{title:"✧ Some Infos ✧",author:"Ender Dargeon",pages:['{"text":"This is a little map to practice the timing for the dragon insta-kill/divide by zero cycle/oneshot/do not miss your chance to blow/idk. "}','{"text":"By default, most RNG has been standardized to make practicing timing easier.\\n\\nThis can be disabled for a more accurate end fight/setup if you wish, just don\'t trick yourself into thinking this is a super consistent trick :)"}','{"text":"There\'s a few other settings/features you can mess with too, and you can click their signs for more detailed info as well.\\n\\n\\nThat\'s all !"}']} 1