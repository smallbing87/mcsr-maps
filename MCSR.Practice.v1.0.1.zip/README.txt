This map was created by Dibedy.

Installation:

1. Fully extract the .zip file. This might take some time.
2. Place the extracted folder into the "saves" folder of your instance.
   Example file directory: C:\...\MultiMC\instances\Practice\.minecraft\saves
3. Start the instance and select the map from your world list.

If you break a sign, block etc you can use "/trigger repairhub" to fully repair the hub

Feedback:

If you find any bugs, have suggestions or any other issues, use the feedback link below.
Feedback Link: https://www.surveymonkey.com/r/YTMFP3J

If you need help with the map or have any other feedback etc, contact @Dibedy on Discord :)


